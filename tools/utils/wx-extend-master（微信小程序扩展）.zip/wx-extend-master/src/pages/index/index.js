const App = getApp()

Page({
    data: {
        type: `grid`,
        components: App.components,
    },
})