import components from './helpers/components'

App({
    components,
})