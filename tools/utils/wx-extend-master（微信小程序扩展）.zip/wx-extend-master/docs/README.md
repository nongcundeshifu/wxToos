# 目录

- [WxRequest - 发送请求](components/request.md)
- [WxService - Promise API](components/service.md)
- [WxValidate - 表单验证](components/validate.md)
- [WxResource - Restful API](components/resource.md)