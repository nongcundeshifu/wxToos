
App({
  onLaunch: function () {
  },

  globalData: {
    systemInfo: {
      ...wx.getSystemInfoSync(),
    },
  },

});

